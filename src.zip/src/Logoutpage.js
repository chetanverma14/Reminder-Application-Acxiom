import React from 'react'

function Logoutpage() {
  return (
    <div className='Home'>Your have been logged out</div>
  )
}

export default Logoutpage